<?php

return [
    'email' => 'sar.ponsford@gmail.com',
    'language' => 'en',
    'name' => 'Sarah Ponsford',
    'role' => 'writer'
];