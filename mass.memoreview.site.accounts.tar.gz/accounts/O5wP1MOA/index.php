<?php

return [
    'email' => 'luby.julia@gmail.com',
    'language' => 'en',
    'name' => 'Julia Luby',
    'role' => 'writer'
];