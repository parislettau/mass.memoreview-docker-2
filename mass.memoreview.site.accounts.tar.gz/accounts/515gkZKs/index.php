<?php

return [
    'email' => 'elizabaker102@gmail.com',
    'language' => 'en',
    'name' => 'Eliza Baker',
    'role' => 'writer'
];