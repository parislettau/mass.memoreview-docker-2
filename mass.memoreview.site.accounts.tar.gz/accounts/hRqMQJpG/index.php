<?php

return [
    'email' => 'ellahowells77@gmail.com',
    'language' => 'en',
    'name' => 'Ella Howells',
    'role' => 'writer'
];