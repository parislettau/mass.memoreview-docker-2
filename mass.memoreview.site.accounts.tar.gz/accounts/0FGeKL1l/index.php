<?php

return [
    'email' => 'sueann-c@outlook.com',
    'language' => 'en',
    'name' => 'Sueann Chen',
    'role' => 'writer'
];