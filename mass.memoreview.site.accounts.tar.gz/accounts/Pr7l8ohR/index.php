<?php

return [
    'email' => 'frank@greenant.net',
    'language' => 'en',
    'name' => 'Frank',
    'role' => 'admin'
];