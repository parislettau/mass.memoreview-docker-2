<?php

return [
    'email' => 'nica@n-r.com.au',
    'language' => 'en',
    'name' => 'Nica Nervegna-Reed',
    'role' => 'writer'
];