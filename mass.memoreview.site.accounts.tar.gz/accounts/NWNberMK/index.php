<?php

return [
    'email' => 'beatrixstarlime444@gmail.com',
    'language' => 'en',
    'name' => 'Beatrix Brenneman',
    'role' => 'writer'
];