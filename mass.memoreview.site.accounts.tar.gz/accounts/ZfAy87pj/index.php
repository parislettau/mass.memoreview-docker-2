<?php

return [
    'email' => 'emilywinslade@hotmail.com.au',
    'language' => 'en',
    'name' => 'Emily Winslade',
    'role' => 'writer'
];