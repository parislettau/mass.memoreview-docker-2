<?php

return [
    'email' => 'nlig0002@student.monash.edu',
    'language' => 'en',
    'name' => 'Nicholas Trifiletti',
    'role' => 'writer'
];