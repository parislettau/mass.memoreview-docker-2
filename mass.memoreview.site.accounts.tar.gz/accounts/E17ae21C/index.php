<?php

return [
    'email' => 'uswa.qureshi9@gmail.com',
    'language' => 'en',
    'name' => 'Uswa Qureshi',
    'role' => 'writer'
];