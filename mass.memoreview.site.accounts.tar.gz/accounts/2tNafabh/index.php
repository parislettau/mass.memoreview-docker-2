<?php

return [
    'email' => 'ksagrabb@student.unimelb.edu.au',
    'language' => 'en',
    'name' => 'Karl Sagrabb',
    'role' => 'writer'
];