<?php

return [
    'email' => 'editor@memoreview.net',
    'language' => 'en',
    'name' => 'Memo Review',
    'role' => 'admin'
];