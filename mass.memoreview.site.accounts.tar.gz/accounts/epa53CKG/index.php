<?php

return [
    'email' => 'biancaarthurhull@gmail.com',
    'language' => 'en',
    'name' => 'Bianca Arthur-Hull',
    'role' => 'writer'
];