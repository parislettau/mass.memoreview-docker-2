<?php

return [
    'email' => 'jenniferhun21@outlook.com',
    'language' => 'en',
    'name' => 'Jennifer Hunt',
    'role' => 'writer'
];