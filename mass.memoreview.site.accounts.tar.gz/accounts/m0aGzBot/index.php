<?php

return [
    'email' => 'oliviastephen2000@gmail.com',
    'language' => 'en',
    'name' => 'Olivia Stephen',
    'role' => 'writer'
];