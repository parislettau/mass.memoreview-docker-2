<?php

return [
    'email' => 'lydia.mard@gmail.com',
    'language' => 'en',
    'name' => 'Lydia Mardirian',
    'role' => 'writer'
];