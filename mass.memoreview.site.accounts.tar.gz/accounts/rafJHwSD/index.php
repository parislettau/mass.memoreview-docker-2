<?php

return [
    'email' => 'erin.j.hallyburton@gmail.com',
    'language' => 'en',
    'name' => 'Erin Hallyburton',
    'role' => 'writer'
];