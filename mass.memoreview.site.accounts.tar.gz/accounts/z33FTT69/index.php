<?php

return [
    'email' => 'jenniferhunt21@outlook.com',
    'language' => 'en',
    'name' => 'Jennifer Hunt',
    'role' => 'writer'
];