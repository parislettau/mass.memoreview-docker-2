<?php

return [
    'email' => 'camille.orel@hotmail.com',
    'language' => 'en',
    'name' => 'Camille Orel',
    'role' => 'writer'
];